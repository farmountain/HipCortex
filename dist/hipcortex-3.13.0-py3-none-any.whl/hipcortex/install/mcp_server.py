#!/usr/bin/env python3
"""HipCortex MCP Server — Model Context Protocol (2024-11-05) over stdio.

Exposes HipCortex memory as tools for Cursor, Claude Code, Windsurf, Zed AI,
and any MCP-compatible AI coding assistant.

Protocol: JSON-RPC 2.0 over stdin/stdout
Dependencies: Python 3.9+ stdlib + requests (pip install requests)

Usage:
    python server.py

Environment variables:
    HIPCORTEX_URL      Base URL (default: http://localhost:3030)
    HIPCORTEX_API_KEY  Optional X-Api-Key for managed SaaS tiers
    HIPCORTEX_TIMEOUT  Request timeout in seconds (default: 10)
"""

from __future__ import annotations

import json
import os
import sys
import threading
import urllib.parse
from typing import Any

import requests

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

HIPCORTEX_URL = os.getenv("HIPCORTEX_URL", "http://localhost:3030").rstrip("/")
API_KEY       = os.getenv("HIPCORTEX_API_KEY", "")
TIMEOUT       = int(os.getenv("HIPCORTEX_TIMEOUT", "30"))

# Session harness state (one MCP process lifetime). Soft substrate-first nudge:
# prefer get_live_beliefs / reflect before search_memory. Never hard-blocks.
# Disable: HIPCORTEX_HARNESS_SOFT=0
_live_beliefs_seen_actors: set = set()  # per-actor discipline: tracks who called get_live_beliefs

_HARNESS_SEARCH_WARN = (
    "[harness] Prefer get_live_beliefs FIRST before search (substrate-first). "
    "Continuing with search..."
)

# ---------------------------------------------------------------------------
# Context budget — per-actor token metering (session-scoped, resets on restart)
#
# substrate_tokens   = bytes//4 of get_live_beliefs responses (actual LLM spend)
# naive_transcript_tokens = estimated bytes//4 of full Temporal history (dumb baseline)
# Ratio naive/substrate proves the OpEx drop from using substrate-first turns.
# ---------------------------------------------------------------------------
_budget_lock: threading.Lock = threading.Lock()
_actor_budget: dict = {}

# Wall guard — substrate output budget per turn.  Measures MCP output only.
# Host context (conversation history, tool dumps, KV cache) is NOT measured here.
WALL_TOKEN_BUDGET: int = int(os.getenv("WALL_TOKEN_BUDGET", "8000"))
_wall_exceeded_actors: set = set()  # per-session dedup: write Reflexion once per actor


def _get_actor_budget(actor: str) -> dict:
    with _budget_lock:
        return dict(_actor_budget.get(actor, {
            "substrate_tokens": 0, "turns": 0,
            "naive_transcript_tokens": 0, "consolidation_savings": 0,
        }))


def _charge_budget(actor: str, substrate_bytes: int,
                   naive_bytes: int = 0, is_turn: bool = False) -> None:
    with _budget_lock:
        b = _actor_budget.setdefault(actor, {
            "substrate_tokens": 0, "turns": 0,
            "naive_transcript_tokens": 0, "consolidation_savings": 0,
        })
        b["substrate_tokens"] += substrate_bytes // 4
        b["naive_transcript_tokens"] += naive_bytes // 4
        if is_turn:
            b["turns"] += 1


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def _headers() -> dict:
    h = {"Content-Type": "application/json", "X-Actor": "mcp"}
    if API_KEY:
        h["X-Api-Key"] = API_KEY
    return h

def _get(path: str) -> dict:
    resp = requests.get(f"{HIPCORTEX_URL}{path}", headers=_headers(), timeout=TIMEOUT)
    resp.raise_for_status()
    return resp.json()

def _post(path: str, body: dict) -> dict:
    resp = requests.post(f"{HIPCORTEX_URL}{path}", json=body, headers=_headers(), timeout=TIMEOUT)
    resp.raise_for_status()
    return resp.json()

def _delete(path: str) -> dict:
    resp = requests.delete(f"{HIPCORTEX_URL}{path}", headers=_headers(), timeout=TIMEOUT)
    resp.raise_for_status()
    return resp.json()

def _req(method: str, path: str, payload: dict | None = None) -> dict:
    """Issue an arbitrary-method request against HipCortex and decode the response.

    Returns the decoded JSON body on success. On a transport failure or a non-2xx
    status it returns ``{"error": ...}`` instead of raising, matching the
    fail-silent contract used by the passive observers: an MCP tool call must
    always produce a result the model can read, even when the server is down or
    the route does not exist.

    ``_post``/``_get``/``_delete`` raise via ``raise_for_status()``, which made
    every caller of this helper crash with ``NameError`` before this definition
    existed — 17 handlers referenced ``_req`` and none could ever succeed.
    """
    url = f"{HIPCORTEX_URL}{path}"
    try:
        resp = requests.request(
            method.upper(),
            url,
            json=payload,
            headers=_headers(),
            timeout=TIMEOUT,
        )
    except Exception as exc:  # noqa: BLE001 — fail-silent by contract
        return {"error": f"{method.upper()} {path} failed: {exc}"}

    if not resp.ok:
        detail = (resp.text or "").strip()
        if len(detail) > 500:
            detail = detail[:500] + "..."
        return {
            "error": f"{method.upper()} {path} -> HTTP {resp.status_code}",
            "status": resp.status_code,
            "detail": detail,
        }

    if resp.status_code == 204 or not resp.content:
        return {}
    try:
        return resp.json()
    except ValueError:
        return {"raw": resp.text}

# ---------------------------------------------------------------------------
# MCP tool definitions
# ---------------------------------------------------------------------------

TOOLS = [
    {
        "name": "add_memory",
        "description": (
            "Store a memory record in HipCortex. "
            "Use to remember decisions, code patterns, bug fixes, architectural choices, "
            "or any context that should persist across sessions."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["actor", "action", "target"],
            "properties": {
                "actor": {
                    "type": "string",
                    "description": "Scope identifier — use project name or 'global' (e.g. 'my-app', 'user-42')",
                },
                "action": {
                    "type": "string",
                    "description": "What happened (e.g. 'decided', 'implemented', 'fixed', 'noted')",
                },
                "target": {
                    "type": "string",
                    "description": "The content to remember — be specific and self-contained",
                },
                "record_type": {
                    "type": "string",
                    "enum": ["Temporal", "Symbolic", "Procedural", "Reflexion", "Perception", "Episodic", "Semantic", "LongTerm", "ShortTerm", "Working", "Reflexive", "Perceptual"],
                    "default": "Temporal",
                },
                "ttl_seconds": {
                    "type": "integer",
                    "description": "Auto-expire after N seconds (omit for permanent memory)",
                },
                "intent_id": {
                    "type": "string",
                    "description": (
                        "Open ActionIntent this add closes; routes a Temporal add through "
                        "the Accept-Receipt seam instead of POST /memory/add."
                    ),
                },
            },
        },
    },
    {
        "name": "search_memory",
        "description": (
            "Search stored memories by keyword. "
            "Use before starting a task to recall relevant past decisions or context. "
            "Prefer get_live_beliefs first for project-state questions "
            "(substrate-first soft harness may warn if search is used first). "
            "Search remains available."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["query"],
            "properties": {
                "query": {"type": "string", "description": "What to search for"},
                "actor": {"type": "string", "description": "Filter by actor/scope (optional)"},
                "limit": {"type": "integer", "default": 10},
            },
        },
    },
    {
        "name": "forget_actor",
        "description": (
            "GDPR hard-delete all records for an actor via a ForgetActor delta on "
            "POST /v1/cognitive/transact."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["actor"],
            "properties": {
                "actor": {"type": "string", "description": "Actor whose records to delete"},
                "actor_id": {
                    "type": "string",
                    "description": "Legacy alias for actor; accepted for compatibility",
                },
            },
        },
    },
    {
        "name": "merge_actor",
        "description": (
            "Move all memory records from one actor to another (MOVE semantics: "
            "source actor records are deleted after being re-assigned to target). "
            "Use to consolidate two agent identities or rename an actor."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["source", "target"],
            "properties": {
                "source": {"type": "string", "description": "Actor whose records to move away from"},
                "target": {"type": "string", "description": "Actor to receive the moved records"},
            },
        },
    },
    {
        "name": "get_stats",
        "description": "Get memory store statistics: total records, types, unique actors.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "search_code",
        "description": (
            "Search the HipCortex code knowledge graph for relevant symbols, functions, classes. "
            "Use this BEFORE reading files — it returns targeted symbol info in ~100 tokens instead of "
            "reading entire files (~10k tokens). Works after running 'hipcortex index' on the codebase."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["query"],
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Symbol name, function, class, or concept to find in the codebase",
                },
                "limit": {
                    "type": "integer",
                    "default": 5,
                    "description": "Max symbols to return",
                },
            },
        },
    },
    {
        "name": "link_memories",
        "description": "Create a directed graph edge between two memory records in the CausalTopoGraph. Use to model causal, temporal, or semantic relationships between memories.",
        "inputSchema": {
            "type": "object",
            "required": ["source_id", "target_id"],
            "properties": {
                "source_id": {"type": "string", "description": "UUID of the source memory record"},
                "target_id": {"type": "string", "description": "UUID of the target memory record"},
                "relation": {"type": "string", "default": "related", "description": "Edge label (e.g. \"caused\", \"follows\", \"related\")"},
            },
        },
    },
    {
        "name": "get_neighbors",
        "description": "Return memory records directly linked to a seed record via the CausalTopoGraph. Use to explore local context around a known memory.",
        "inputSchema": {
            "type": "object",
            "required": ["record_id"],
            "properties": {
                "record_id": {"type": "string", "description": "UUID of the seed memory record"},
                "limit": {"type": "integer", "default": 10, "description": "Max neighbors to return"},
            },
        },
    },
    {
        "name": "search_related",
        "description": "PPR-ranked related memory search. Uses Personalized PageRank (alpha=0.85, 20 rounds) to surface the most contextually relevant memories seeded from a given record. Call after search_memory to expand context graph-first.",
        "inputSchema": {
            "type": "object",
            "required": ["seed_id"],
            "properties": {
                "seed_id": {"type": "string", "description": "UUID of the seed memory record"},
                "limit": {"type": "integer", "default": 10, "description": "Max results to return"},
            },
        },
    },
    {
        "name": "graph_ppr",
        "description": (
            "Personalized PageRank over the live CausalTopoGraph substrate. "
            "Use for topology-first exploration of symbolic graph nodes (not only memory UUIDs). "
            "Prefer after link_memories or deconstruct_hypothesis."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "seed": {"type": "string", "description": "Optional seed node symbolic_id"},
                "limit": {"type": "integer", "default": 10},
            },
        },
    },
    {
        "name": "deconstruct_hypothesis",
        "description": (
            "Parse free text into candidate causal nodes/edges (rule-based; optional llm_json). "
            "Use before applying structure to the topo graph via apply_hypothesis."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["text"],
            "properties": {
                "text": {"type": "string", "description": "Hypothesis text, e.g. 'rain causes floods'"},
                "llm_json": {
                    "type": "string",
                    "description": "Optional LLM JSON: {\"edges\":[{\"from\",\"to\",\"relation\"?}]}",
                },
                "apply": {
                    "type": "boolean",
                    "default": False,
                    "description": "If true, also apply edges to live topo graph (POST /topo/apply-hyp)",
                },
            },
        },
    },
    {
        "name": "check_topo_edge",
        "description": (
            "Check whether adding a causal edge from→to would contradict the CausalTopoGraph "
            "(cycle or high-strength reverse)."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["from", "to"],
            "properties": {
                "from": {"type": "string"},
                "to": {"type": "string"},
            },
        },
    },
    {
        "name": "rollout",
        "description": (
            "World-model multi-step rollout. Default Dirichlet MAP after observe; "
            "mode=mcts uses goal-shaped UCB1 search. Requires prior worldmodel observations "
            "or mode=mcts with observed transitions."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["initial_state"],
            "properties": {
                "initial_state": {"type": "string"},
                "actions": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Required unless mode=mcts",
                },
                "mode": {
                    "type": "string",
                    "enum": ["dirichlet", "mcts", "ensemble"],
                    "default": "dirichlet",
                },
                "goal_state": {"type": "string", "description": "Goal for MCTS reward shaping"},
                "iterations": {"type": "integer", "default": 50},
                "max_depth": {"type": "integer", "default": 3},
            },
        },
    },
    {
        "name": "can_execute",
        "description": "Query SelfModel gate: should the agent execute this operation?",
        "inputSchema": {
            "type": "object",
            "required": ["operation"],
            "properties": {
                "operation": {
                    "type": "string",
                    "description": "Operation name (e.g. add_memory, rollout, search_memory)",
                },
            },
        },
    },
    {
        "name": "delete_memory",
        "description": "Delete a single memory record by UUID. Use for targeted removal without forgetting an entire actor.",
        "inputSchema": {
            "type": "object",
            "required": ["record_id"],
            "properties": {
                "record_id": {"type": "string", "description": "UUID of the memory record to delete"},
            },
        },
    },
    {
        "name": "get_live_beliefs",
        "description": (
            "Get the latest unique beliefs per actor+action pair. "
            "Returns the most recent value for each fact the system has observed. "
            "Per Claude Agent Harness: call this FIRST before any project-state question."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "actor": {"type": "string", "description": "Filter to a specific actor (optional)"},
                "limit": {"type": "integer", "default": 20, "description": "Max beliefs to return"},
                "min_conf": {"type": "number", "default": 0.0, "description": "Minimum confidence threshold [0.0, 1.0]"},
            },
        },
    },
    {
        "name": "purge_expired",
        "description": "Trigger purge of all TTL-expired memory records from the store.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "reflect",
        "description": (
            "Substrate-first CoT / Bayesian hypothesis sampling via AureusBridge. "
            "POST /memory/reflect — search memory context, sample hypotheses with confidence. "
            "Use for uncertain architectural decisions or counterfactual reasoning before final answer."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["query"],
            "properties": {
                "query": {
                    "type": "string",
                    "description": "What to reflect on (e.g. 'Postgres vs RocksDB for session store')",
                },
            },
        },
    },
    {
        "name": "predict",
        "description": (
            "World-model single-step prediction P(s'|s,a). "
            "POST /worldmodel/predict with state + action; returns next-state probabilities + entropy."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["state", "action"],
            "properties": {
                "state": {
                    "type": "string",
                    "description": "Current world-model state label",
                },
                "action": {
                    "type": "string",
                    "description": "Action applied from that state",
                },
            },
        },
    },
    {
        "name": "compute_state_diff",
        "description": (
            "Compute a causal StateDiff over a tx-log range [from_tx, to_tx]. "
            "Returns MemoryDelta (added/archived/updated counts), WorldModelDelta, "
            "and CausalAttributionPaths. Range cap: 10,000 entries."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["from_tx", "to_tx"],
            "properties": {
                "from_tx": {"type": "integer", "description": "Start tx id (inclusive)"},
                "to_tx":   {"type": "integer", "description": "End tx id (inclusive)"},
            },
        },
    },
    {
        "name": "simulate_rollout",
        "description": (
            "Simulate a k-step (k≤5) world-model rollout from an initial state "
            "over a sequence of actions using Dirichlet-MAP transitions. "
            "Returns predicted_state, mode, and uncertainty. "
            "Use before committing to a multi-step action plan."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["initial_state", "actions"],
            "properties": {
                "initial_state": {"type": "string", "description": "Starting state label"},
                "actions": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Action sequence (max 5 steps)",
                },
                "max_depth": {"type": "integer", "description": "Override max depth (≤5, default 5)"},
            },
        },
    },
    {
        "name": "get_system_health",
        "description": (
            "Get SelfModel health + CalibrationTracker metrics: overall health score, "
            "calibration_score, prediction_error_ewma, consolidation_pressure, "
            "epistemic_entropy, and whether the system is healthy."
        ),
        "inputSchema": {"type": "object", "properties": {}},
    },
    # Phase 5: Agent Surfaces
    {
        "name": "cognitive_transact",
        "description": "Apply a CognitiveDelta to the cognitive substrate. Supports AddMemory, Consolidate, ForgetActor, ArchiveRecord.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "delta": {"type": "object", "description": "CognitiveDelta (must include 'type' field)"},
                "actor": {"type": "string", "description": "Actor performing the transaction"},
            },
            "required": ["delta", "actor"],
        },
    },
    {
        "name": "open_intent",
        "description": "POST /intent/open — issue a Probe ActionIntent. GroundingGate blocks instrumental planning until the env entity has ≥4 Observed contacts. Use this to probe an entity; await accept_receipt to close it.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "actor": {"type": "string", "description": "Actor issuing the intent"},
                "target_entity": {"type": "string", "description": "Entity to probe (e.g. 'filesystem', 'api_gateway')"},
                "deadline_ms": {"type": "integer", "description": "Expiry timeout in ms (default 30000)"},
                "goal_id": {"type": "string", "description": "Optional goal UUID this probe serves"},
            },
            "required": ["actor", "target_entity"],
        },
    },
    {
        "name": "accept_receipt",
        "description": "POST /intent/receipt — submit host observation as ActionReceipt, the only valid path for env observations. Atomically writes Temporal{receipt_observation} and updates WM entity_contacts. Do NOT use add_memory for env observations.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "actor": {"type": "string", "description": "Actor submitting the receipt"},
                "intent_id": {"type": "string", "description": "UUID of the open ActionIntent this receipt closes"},
                "ok": {"type": "boolean", "description": "Whether the probe/action succeeded"},
                "observation": {"type": "object", "description": "Raw payload received from the env sensor"},
                "sensor_path": {"type": "string", "description": "Which MCP/skill produced this (e.g. 'mcp:filesystem')"},
            },
            "required": ["actor", "intent_id", "observation", "sensor_path"],
        },
    },
    {
        "name": "cognitive_diff",
        "description": "Get causal StateDiff between two tx-log cursors.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "from_tx": {"type": "integer"},
                "to_tx": {"type": "integer"},
            },
            "required": ["from_tx", "to_tx"],
        },
    },
    {
        "name": "self_health",
        "description": "GET /v1/self/health — SelfModel health metrics with healthy boolean.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "cognitive_snapshot",
        "description": "GET /v1/cognitive/snapshot — full cognitive state snapshot for an actor.",
        "inputSchema": {
            "type": "object",
            "properties": {"actor": {"type": "string", "default": ""}},
        },
    },
    {
        "name": "fork_create",
        "description": "POST /v1/fork — create a SimulationFork (CoW snapshot of cognitive state).",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "fork_step",
        "description": "POST /v1/fork/{fork_id}/step — advance a fork by one action.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "fork_id": {"type": "string"},
                "action": {"type": "string"},
            },
            "required": ["fork_id", "action"],
        },
    },
    {
        "name": "fork_snapshot",
        "description": "GET /v1/fork/{fork_id}/snapshot — read fork cognitive snapshot.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "fork_id": {"type": "string"},
                "actor": {"type": "string", "default": ""},
            },
            "required": ["fork_id"],
        },
    },
    {
        "name": "fork_delete",
        "description": "DELETE /v1/fork/{fork_id} — discard a SimulationFork.",
        "inputSchema": {
            "type": "object",
            "properties": {"fork_id": {"type": "string"}},
            "required": ["fork_id"],
        },
    },
    {
        "name": "fork_rollout",
        "description": "POST /v1/fork/{fork_id}/rollout — k-step (k≤5) hybrid Kalman rollout.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "fork_id": {"type": "string"},
                "actions": {"type": "array", "items": {"type": "string"}},
                "sigma2_max": {"type": "number", "default": 0.25},
            },
            "required": ["fork_id", "actions"],
        },
    },
    {
        "name": "consolidate_memory",
        "description": "Mine recurring causal subgraphs and induce Skill+Belief records via AutoConsolidate.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "min_frequency": {"type": "integer", "default": 3, "description": "Minimum causal path frequency to qualify for induction."},
                "actor": {"type": "string", "default": "mcp", "description": "Actor the AutoConsolidate transaction is attributed to."},
            },
            "required": [],
        },
    },
    {
        "name": "archive_record",
        "description": "Archive or delete a single record via ArchiveRecord delta.",
        "inputSchema": {
            "type": "object",
            "properties": {"id": {"type": "string"}},
            "required": ["id"],
        },
    },
    {
        "name": "workspace_open",
        "description": "Open a new workspace (Private or Shared) for scoped multi-agent cognition.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {"type": "string", "description": "UUID for the workspace."},
                "mode": {"type": "string", "enum": ["Private", "Shared"], "default": "Private"},
            },
            "required": ["workspace_id"],
        },
    },
    {
        "name": "workspace_merge",
        "description": "Merge one Shared workspace into another via OR-Set CRDT convergence.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "from_id": {"type": "string", "description": "Source workspace UUID."},
                "into_id": {"type": "string", "description": "Target workspace UUID."},
            },
            "required": ["from_id", "into_id"],
        },
    },
    {
        "name": "retract_belief",
        "description": "Retract a belief record, triggering JTMS dependency propagation.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "belief_id": {"type": "string"},
                "reason": {"type": "string", "default": "retracted"},
            },
            "required": ["belief_id"],
        },
    },
    {
        "name": "get_state_export",
        "description": "Export full versioned Cognitive State snapshot (schema_version=0.8.0, tx_cursor, beliefs, goals, world state). Use for agent handover, substrate audit, or cross-session state transfer.",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "twin_create",
        "description": "POST /v1/twin — create a DigitalTwin (continuous simulation fork with RK4 dynamics).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "dim": {"type": "integer", "default": 4, "description": "State vector dimension."},
                "dt": {"type": "number", "default": 0.1, "description": "RK4 integration timestep."},
                "max_covariance": {"type": "number", "default": 100.0, "description": "Sigma-norm halt threshold."},
            },
            "required": [],
        },
    },
    {
        "name": "twin_step",
        "description": "POST /v1/twin/{twin_id}/step — advance a DigitalTwin by one discrete action.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "twin_id": {"type": "string"},
                "action": {"type": "string"},
            },
            "required": ["twin_id", "action"],
        },
    },
    {
        "name": "twin_rollout",
        "description": "POST /v1/twin/{twin_id}/rollout — multi-step hybrid (discrete+continuous) rollout.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "twin_id": {"type": "string"},
                "actions": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["twin_id", "actions"],
        },
    },
    {
        "name": "twin_get",
        "description": "GET /v1/twin/{twin_id} — retrieve trajectory and record count for a DigitalTwin.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "twin_id": {"type": "string"},
            },
            "required": ["twin_id"],
        },
    },
    {
        "name": "experience_tiers",
        "description": "GET /v1/experience/{actor}/tiers — raw/episode/abstract counts and compression ratio for the experience pyramid.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "actor": {"type": "string"},
            },
            "required": ["actor"],
        },
    },
    {
        "name": "mgv_check",
        "description": "POST /v1/mgv/check — Monitor-Generate-Verify: compute FOK/JOL divergence and quarantine signal.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "justification_strength": {"type": "number"},
                "calibration_score": {"type": "number"},
                "historical_success_rate": {"type": "number"},
            },
            "required": [],
        },
    },
    {
        "name": "causal_intervene",
        "description": "POST /v1/causal/intervene — apply do(var=value) surgical intervention on the causal graph.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "var": {"type": "string"},
                "value": {"type": "number"},
                "actor": {"type": "string"},
            },
            "required": ["var", "value"],
        },
    },
    {
        "name": "causal_counterfactual",
        "description": "POST /v1/causal/counterfactual — compute counterfactual outcome under intervention.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "actual_state": {"type": "object"},
                "intervention_var": {"type": "string"},
                "intervention_value": {"type": "number"},
                "actor": {"type": "string"},
            },
            "required": ["actual_state", "intervention_var", "intervention_value"],
        },
    },
    {
        "name": "causal_credit_assign",
        "description": "POST /v1/causal/credit-assign — run AAP credit assignment for a failure signal.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "failure_signal": {"type": "string", "enum": ["MaxIterations", "CoherenceViolation"]},
                "actor": {"type": "string"},
            },
            "required": ["failure_signal"],
        },
    },
    {
        "name": "causal_rewrite_equation",
        "description": "POST /v1/causal/rewrite-equation — rewrite structural equation weights for a causal node.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "node_id": {"type": "string"},
                "new_weights": {"type": "array", "items": {"type": "number"}},
                "actor": {"type": "string"},
            },
            "required": ["node_id", "new_weights"],
        },
    },
    {
        "name": "cognitive_report",
        "description": "GET /v1/cognitive/report — single-call aggregator answering all 10 cognitive questions (goals, beliefs, decisions, failures, emergent abstractions, uncertainties, authorized actions, next recommendation).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "actor": {"type": "string"},
            },
            "required": [],
        },
    },
    {
        "name": "list_authorized_actions",
        "description": "GET /v1/actions/authorized — list all ops the current self-model authorizes via ExecutionGate.",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "get_provenance",
        "description": "GET /v1/memory/{id}/provenance — BFS provenance chain (derived_from + evidence links) up to depth 20.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "UUID of the memory record"},
            },
            "required": ["id"],
        },
    },
    {
        "name": "run_omega_loop",
        "description": "POST /v1/loop/omega — run one omega cognitive loop iteration (detect coverage gaps, simulate rollout, attribute credit, mutate beliefs). Returns iterations count.",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "recommend_tools",
        "description": "POST /agent/recommend-tools — given a task description, returns recommended MCP servers, skills, tech stack, and setup commands. CALL THIS FIRST for any complex multi-step task before starting the ReAct loop.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "Natural language description of the task (e.g. 'build a full-stack app', 'research hotel costs for Kyoto trip').",
                },
            },
            "required": ["task"],
        },
    },
    {
        "name": "clarify_goal",
        "description": "POST /agent/clarify-goal — turns a vague task into a structured GoalPayload scaffold with clarifying questions, suggested success_factors, and recommended max_iterations. Call after recommend_tools, before creating a goal.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "Raw task description to clarify."},
            },
            "required": ["task"],
        },
    },
    {
        "name": "plan_validation",
        "description": "POST /agent/plan-validation — given success_factors, returns a test plan: how to verify each factor (tool, command, expected evidence). Call before the ReAct loop to know how you'll confirm success.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "success_factors": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of success_factors from the GoalPayload.",
                },
            },
            "required": ["success_factors"],
        },
    },
    {
        "name": "check_progress",
        "description": "POST /agent/check-progress — per-iteration progress gate. Given current observations and success_factors, returns satisfied/pending factors, on-track signal, and recommended next action. Call at end of each ReAct iteration.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "success_factors": {"type": "array", "items": {"type": "string"}},
                "observations": {"type": "array", "items": {"type": "string"}, "description": "Temporal record targets from this session."},
                "iteration": {"type": "integer"},
                "max_iterations": {"type": "integer"},
            },
            "required": ["success_factors", "observations", "iteration", "max_iterations"],
        },
    },
    {
        "name": "should_exit",
        "description": "POST /agent/should-exit — loop exit gate. Returns continue|succeed|fail|escalate. MUST call at the end of every ReAct iteration to prevent indefinite loops. Hard cap: fails at max_iterations regardless of progress.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "iteration": {"type": "integer"},
                "max_iterations": {"type": "integer"},
                "progress_ratio": {"type": "number", "description": "0.0–1.0, from check_progress.progress_ratio."},
                "surprise_signal": {"type": "number", "description": "0.0–1.0 entropy/surprise from substrate. Use 0.0 if unknown."},
            },
            "required": ["iteration", "max_iterations", "progress_ratio"],
        },
    },
    {
        "name": "loop_subscribe",
        "description": "POST /v1/loop/subscribe — spawn a SubstrateDaemon background maintenance thread (GC + AutoConsolidate). Returns handle_id for status queries.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "actor": {"type": "string", "description": "Actor namespace for this daemon handle (default: 'daemon')."},
            },
        },
    },
    {
        "name": "loop_status",
        "description": "GET /v1/loop/status/:handle — query iteration count and running/stopped status of a SubstrateDaemon handle.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "handle_id": {"type": "string", "description": "UUID returned by loop_subscribe."},
            },
            "required": ["handle_id"],
        },
    },
    {
        "name": "get_verifier_report",
        "description": "GET /goal/:id/verify — retrieve the ReactEngine verifier_report Belief for a goal. Contains verified flag, final_status, and per-factor scores.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "goal_id": {"type": "string", "description": "UUID of the goal record."},
            },
            "required": ["goal_id"],
        },
    },
    {
        "name": "get_budget",
        "description": (
            "Returns per-actor context token budget for this MCP session. "
            "Shows substrate_tokens (actual spend via get_live_beliefs) vs "
            "naive_transcript_tokens (estimated cost of a raw growing transcript). "
            "Use to measure OpEx savings from substrate-first turns vs long-context baseline. "
            "Compression ratio = naive_per_turn / substrate_per_turn."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "actor": {"type": "string"},
            },
            "required": [],
        },
    },
]

RESOURCES = [
    {
        "uri": "hipcortex://context/relevant",
        "name": "Relevant Memory Context",
        "description": "Top-k memories relevant to the current session, auto-injected.",
        "mimeType": "text/plain",
    },
    {
        "uri": "hipcortex://beliefs/current",
        "name": "Current Beliefs",
        "description": "Active belief records from HipCortex symbolic store.",
        "mimeType": "application/json",
    },
    {
        "uri": "hipcortex://beliefs/live",
        "name": "Live Beliefs",
        "description": "Active Belief records with confidence + JTMS labels (alias of beliefs/current).",
        "mimeType": "application/json",
    },
    {
        "uri": "hipcortex://context/conversation",
        "name": "Conversation History",
        "description": "Recent temporal memory traces for this session.",
        "mimeType": "text/plain",
    },
    {
        "uri": "hipcortex://state/diff",
        "name": "Recent State Diff",
        "description": "ΔS for last 5 transactions — epistemic value of recent turns.",
        "mimeType": "application/json",
    },
    {
        "uri": "hipcortex://self/health",
        "name": "Self-Model Health",
        "description": "Current calibration score, epistemic entropy, consolidation pressure.",
        "mimeType": "application/json",
    },
    {
        "uri": "hipcortex://experience/tiers",
        "name": "Experience Tier Stats",
        "description": "Raw/episode/abstract counts and compression ratio for the current session actor's experience pyramid.",
        "mimeType": "application/json",
    },
]

# ---------------------------------------------------------------------------
# Tool execution
# ---------------------------------------------------------------------------

def handle_add_memory(args: dict) -> str:
    # Adapter: if intent_id present on a Temporal record, route through AcceptReceipt seam.
    record_type = args.get("record_type", "Temporal")
    if args.get("intent_id") and record_type.lower() in ("temporal", "t"):
        return handle_accept_receipt({
            "actor": args["actor"],
            "intent_id": args["intent_id"],
            "ok": True,
            "observation": {"action": args["action"], "target": args["target"]},
            "sensor_path": "add_memory_adapter",
        })
    body = {"actor": args["actor"], "action": args["action"], "target": args["target"]}
    if "record_type" in args:
        body["record_type"] = args["record_type"]
    if "ttl_seconds" in args:
        body["ttl_seconds"] = args["ttl_seconds"]
    result = _req("POST", "/memory/add", body)
    if "error" in result:
        detail_str = result.get("detail", "")
        try:
            reason = json.loads(detail_str).get("error") or detail_str
        except Exception:
            reason = detail_str or result["error"]
        return f"✗ Memory refused (HTTP {result.get('status', '?')}): {reason}"
    return f"✓ Memory stored (id: {result.get('record_id', 'unknown')})\n  [{args['action']}] {args['target']}"


def handle_search_memory(args: dict) -> str:
    body = {"query": args["query"], "limit": args.get("limit", 10)}
    result = _post("/memory/search", body)
    search_results = result.get("results", [])

    if search_results:
        lines = [
            f"• [{r.get('record', {}).get('action', '?')}] {r.get('record', {}).get('target', '')} "
            f"(actor: {r.get('record', {}).get('actor', '?')}, score: {r.get('score', 0):.2f})"
            for r in search_results
        ]
        return f"Found {len(lines)} result(s):\n" + "\n".join(lines)

    # Fallback: keyword query
    params: dict = {"limit": args.get("limit", 10)}
    if "actor" in args:
        params["actor"] = args["actor"]
    qs = urllib.parse.urlencode(params)
    result2 = _get(f"/memory/query?{qs}")
    records = result2.get("records", [])
    if not records:
        return "No memories found."
    lines = [
        f"• [{r.get('action', '?')}] {r.get('target', '')} (actor: {r.get('actor', '?')})"
        for r in records
    ]
    return f"Found {len(lines)} record(s):\n" + "\n".join(lines)


def handle_get_stats(_args: dict) -> str:
    result = _get("/stats")
    total   = result.get("total_records", 0)
    actors  = result.get("unique_actors", 0)
    by_type = result.get("by_type", {})
    metered = result.get("metering_enabled", False)
    lines = [
        "HipCortex memory store:",
        f"  Total records:  {total}",
        f"  Unique actors:  {actors}",
        f"  Metering:       {'enabled' if metered else 'open mode'}",
    ]
    if by_type:
        lines.append("  By type:")
        for t, count in sorted(by_type.items()):
            lines.append(f"    {t}: {count}")
    return "\n".join(lines)


def handle_search_code(args: dict) -> str:
    query = args.get("query", "")
    limit = args.get("limit", 5)
    try:
        resp = requests.get(
            f"{HIPCORTEX_URL}/graph/search",
            params={"q": query, "limit": limit},
            headers=_headers(),
            timeout=TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
        nodes = data.get("nodes", [])
        if not nodes:
            return (
                f"No code symbols found for '{query}'. "
                "Run 'hipcortex index .' to index the codebase first."
            )
        lines = []
        for n in nodes:
            props = n.get("properties", {})
            label = n.get("label", "?")
            line = props.get("line", "?")
            sig = props.get("signature", props.get("name", label))
            fpath = props.get("file", "")
            lines.append(f"• {sig}  [{fpath}:{line}]")
        return f"Code symbols matching '{query}':\n" + "\n".join(lines)
    except Exception as e:
        return f"Error searching code graph: {e}. Run 'hipcortex index .' first."


def handle_link_memories(args: dict) -> str:
    body = {
        "source_id": args["source_id"],
        "target_id": args["target_id"],
        "relation": args.get("relation", "related"),
    }
    result = _post("/memory/link", body)
    ok = result.get("success", False)
    rel = result.get("relation", "related")
    return (
        f"✓ Link created: {args['source_id']} --[{rel}]--> {args['target_id']}"
        if ok else f"✗ Link failed: {result}"
    )


def handle_get_neighbors(args: dict) -> str:
    record_id = args["record_id"]
    limit = args.get("limit", 10)
    qs = urllib.parse.urlencode({"limit": limit})
    result = _get(f"/memory/neighbors/{record_id}?{qs}")
    records = result.get("records", [])
    if not records:
        return f"No neighbors found for record {record_id}."
    lines = [
        f"• [{r.get('action', '?')}] {r.get('target', '')} (actor: {r.get('actor', '?')}, id: {r.get('id', '?')})"
        for r in records
    ]
    return f"{len(lines)} neighbor(s) of {record_id}:\n" + "\n".join(lines)


def handle_search_related(args: dict) -> str:
    seed_id = args["seed_id"]
    limit = args.get("limit", 10)
    qs = urllib.parse.urlencode({"seed_id": seed_id, "limit": limit})
    result = _get(f"/memory/search/related?{qs}")
    results = result.get("results", [])
    if not results:
        return f"No related memories found for seed {seed_id}. Ensure the record is linked to others."
    lines = [
        f"• [{r.get('record', {}).get('action', '?')}] {r.get('record', {}).get('target', '')} "
        f"(score: {r.get('score', 0):.3f})"
        for r in results
    ]
    return f"{len(lines)} PPR-related result(s):\n" + "\n".join(lines)


def handle_delete_memory(args: dict) -> str:
    record_id = args["record_id"]
    result = _delete(f"/memory/{record_id}")
    ok = result.get("success", False)
    return (
        f"✓ Deleted record {record_id}."
        if ok else f"✗ Delete failed: {result}"
    )


def handle_get_live_beliefs(args: dict) -> str:
    params: dict = {"limit": args.get("limit", 20)}
    if "actor" in args:
        params["actor"] = args["actor"]
    if "min_conf" in args:
        params["min_conf"] = args["min_conf"]
    qs = urllib.parse.urlencode(params)
    result = _get(f"/memory/live_beliefs?{qs}")
    beliefs = result.get("beliefs", [])
    if not beliefs:
        return "No live beliefs found."
    lines = [
        f"• [{b.get('action', '?')}] {b.get('target', '')} (actor: {b.get('actor', '?')})"
        for b in beliefs
    ]
    response_str = f"Live beliefs ({result.get('total', len(beliefs))}):\n" + "\n".join(lines)

    # Context budget metering: charge substrate tokens, estimate naive transcript size.
    actor = args.get("actor", "mcp-session")
    substrate_bytes = len(response_str.encode())
    try:
        stats = _get("/stats")
        naive_bytes = stats.get("total_records", 0) * 200  # ~200 bytes avg per record
    except Exception:
        naive_bytes = substrate_bytes * 10
    _charge_budget(actor, substrate_bytes, naive_bytes, is_turn=True)

    # Wall guard: write one Reflexion per actor when substrate output exceeds budget.
    budget_check = _get_actor_budget(actor)
    turns_check = max(1, budget_check["turns"])
    s_per_turn = budget_check["substrate_tokens"] // turns_check
    if s_per_turn > WALL_TOKEN_BUDGET and actor not in _wall_exceeded_actors:
        _wall_exceeded_actors.add(actor)
        try:
            handle_add_memory({
                "actor": actor, "action": "wall_exceeded",
                "target": "substrate_budget", "memory_type": "Reflexion",
                "content": f"substrate_per_turn={s_per_turn} > wall={WALL_TOKEN_BUDGET}",
                "metadata": {"substrate_per_turn": s_per_turn,
                             "wall_token_budget": WALL_TOKEN_BUDGET},
            })
        except Exception:
            pass

    return response_str


def handle_simulate_rollout(args: dict) -> str:
    actions = args["actions"]
    effective_depth = min(args.get("max_depth", 5), 5)
    if len(actions) > effective_depth:
        return f"✗ Rollout rejected: {len(actions)} actions exceed max_depth={effective_depth} (k≤5 limit)"
    payload = {
        "initial_state": args["initial_state"],
        "actions": actions,
        "max_depth": effective_depth,
    }
    result = _post("/worldmodel/rollout", payload)
    if "error" in result:
        return f"✗ Rollout failed: {result['error']}"
    uncertainty = result.get("uncertainty")
    unc_str = f"{uncertainty:.3f}" if isinstance(uncertainty, (int, float)) else "?"
    return (
        f"Rollout: {result.get('predicted_state', '?')} "
        f"(mode={result.get('mode', '?')}, uncertainty={unc_str})"
    )


def handle_get_system_health(_args: dict) -> str:
    result = _get("/self/health")
    if "error" in result:
        return f"✗ Health check failed: {result['error']}"
    healthy = result.get("healthy", False)
    overall = result.get("overall", 0.0)
    cal = result.get("calibration_score", None)
    ewma = result.get("prediction_error_ewma", None)
    pressure = result.get("consolidation_pressure", None)
    entropy = result.get("epistemic_entropy", None)
    lines = [f"System healthy: {healthy} | overall={overall:.3f}"]
    if cal is not None:
        lines.append(f"calibration_score={cal:.3f} | prediction_error_ewma={ewma:.3f}")
    if pressure is not None:
        lines.append(f"consolidation_pressure={pressure:.3f} | epistemic_entropy={entropy:.3f}")
    return "\n".join(lines)


def handle_cognitive_transact(args: dict) -> str:
    result = _post("/v1/cognitive/transact", {"delta": args["delta"], "actor": args.get("actor", "mcp")})
    return json.dumps(result)

def handle_open_intent(args: dict) -> str:
    return json.dumps(_post("/intent/open", {
        "actor": args.get("actor", "mcp"),
        "target_entity": args["target_entity"],
        "deadline_ms": args.get("deadline_ms", 30000),
        "goal_id": args.get("goal_id"),
    }))

def handle_accept_receipt(args: dict) -> str:
    return json.dumps(_post("/intent/receipt", {
        "actor": args.get("actor", "mcp"),
        "intent_id": args["intent_id"],
        "ok": args.get("ok", True),
        "observation": args.get("observation", {}),
        "sensor_path": args.get("sensor_path", "unknown"),
    }))

def handle_cognitive_diff(args: dict) -> str:
    params = f"from_tx={args['from_tx']}&to_tx={args['to_tx']}"
    resp = requests.get(f"{HIPCORTEX_URL}/v1/cognitive/diff?{params}", headers=_headers(), timeout=TIMEOUT)
    resp.raise_for_status()
    return json.dumps(resp.json())

def handle_self_health(_args: dict) -> str:
    return json.dumps(_get("/v1/self/health"))

def handle_cognitive_snapshot(args: dict) -> str:
    actor = args.get("actor", "")
    resp = requests.get(f"{HIPCORTEX_URL}/v1/cognitive/snapshot", params={"actor": actor}, headers=_headers(), timeout=TIMEOUT)
    resp.raise_for_status()
    return json.dumps(resp.json())

def handle_fork_create(_args: dict) -> str:
    return json.dumps(_post("/v1/fork", {}))

def handle_fork_step(args: dict) -> str:
    return json.dumps(_post(f"/v1/fork/{args['fork_id']}/step", {"action": args["action"]}))

def handle_fork_snapshot(args: dict) -> str:
    actor = args.get("actor", "")
    resp = requests.get(f"{HIPCORTEX_URL}/v1/fork/{args['fork_id']}/snapshot", params={"actor": actor}, headers=_headers(), timeout=TIMEOUT)
    resp.raise_for_status()
    return json.dumps(resp.json())

def handle_fork_delete(args: dict) -> str:
    return json.dumps(_delete(f"/v1/fork/{args['fork_id']}"))

def handle_fork_rollout(args: dict) -> str:
    return json.dumps(_post(f"/v1/fork/{args['fork_id']}/rollout", {"actions": args["actions"], "sigma2_max": args.get("sigma2_max", 0.25)}))

def handle_p5_consolidate(args: dict) -> str:
    actor = args.get("actor", "mcp")
    # Pre-consolidation token estimate
    try:
        pre_records = _get("/stats").get("total_records", 0)
    except Exception:
        pre_records = 0
    pre_tokens = pre_records * 50  # ~200 bytes / 4 per record

    delta = {"type": "AutoConsolidate", "min_frequency": args.get("min_frequency", 3)}
    result = _post("/v1/cognitive/transact", {"delta": delta, "actor": actor})

    # Post-consolidation token estimate
    try:
        post_records = _get("/stats").get("total_records", 0)
    except Exception:
        post_records = pre_records
    post_tokens = post_records * 50
    ratio = round(pre_tokens / max(1, post_tokens), 2) if post_tokens < pre_tokens else 1.0
    savings = max(0, pre_tokens - post_tokens)

    # Write durable Reflexion{consolidation_ratio} for audit trail across restarts
    if pre_records > 0:
        try:
            handle_add_memory({
                "actor": actor,
                "action": "consolidation_ratio",
                "target": "memory_store",
                "memory_type": "Reflexion",
                "content": f"pre={pre_tokens} post={post_tokens} ratio={ratio}",
                "metadata": {"pre_tokens": pre_tokens, "post_tokens": post_tokens,
                             "ratio": ratio, "savings": savings},
            })
        except Exception:
            pass  # fail-silent — metering must not break consolidation

    # Update session budget with savings
    with _budget_lock:
        b = _actor_budget.setdefault(actor, {
            "substrate_tokens": 0, "turns": 0,
            "naive_transcript_tokens": 0, "consolidation_savings": 0,
        })
        b["consolidation_savings"] += savings

    suffix = (
        f" | OpEx: {pre_tokens}→{post_tokens} tokens ({ratio}x compression)"
        if pre_records > 0 else ""
    )
    return json.dumps(result) + suffix


def handle_get_budget(args: dict) -> str:
    actor = args.get("actor", "mcp-session")
    budget = _get_actor_budget(actor)
    turns = max(1, budget["turns"])
    substrate_per_turn = budget["substrate_tokens"] // turns
    naive_per_turn = budget["naive_transcript_tokens"] // turns
    ratio = (
        round(naive_per_turn / max(1, substrate_per_turn), 1)
        if substrate_per_turn > 0 else 0.0
    )
    wall_status = "bounded"
    if substrate_per_turn > WALL_TOKEN_BUDGET:
        wall_status = "exceeded"
    elif substrate_per_turn > int(WALL_TOKEN_BUDGET * 0.8):
        wall_status = "at_risk"

    lines = [
        f"Context budget for actor={actor}:",
        f"  Turns (get_live_beliefs calls): {budget['turns']}",
        f"  Substrate tokens this session:  {budget['substrate_tokens']}",
        f"  Naive transcript estimate:      {budget['naive_transcript_tokens']}",
        f"  Tokens/turn (substrate):        {substrate_per_turn}",
        f"  Tokens/turn (naive):            {naive_per_turn}",
        f"  Compression ratio:              {ratio}x",
        f"  Consolidation savings:          {budget['consolidation_savings']} tokens",
        f"  Wall token budget:              {WALL_TOKEN_BUDGET} tokens/turn",
        f"  Wall status:                    {wall_status}",
        f"  [honest] wall_status measures substrate output only.",
        f"  [honest] Host context (conversation, tool dumps, KV cache) is NOT measured.",
        f"  [honest] Substrate discipline = only get_live_beliefs + one intent per turn.",
    ]
    return "\n".join(lines)

def handle_get_state_export(_args: dict) -> str:
    data = _get("/v1/state/export")
    if "error" in data:
        return f"State export error: {data['error']}"
    sv = data.get("schema_version", "unknown")
    tx = data.get("tx_cursor", 0)
    beliefs = len(data.get("beliefs", {}).get("beliefs", []))
    goals = len(data.get("goals", []))
    return (
        f"State export OK (schema={sv}, tx={tx}, beliefs={beliefs}, goals={goals})\n"
        + json.dumps(data, indent=2)[:3000]
    )

def handle_forget_actor(args: dict) -> str:
    # `actor` is the project-wide spelling (dispatch_tool itself defaults on it);
    # `actor_id` is accepted because an older schema entry advertised it.
    actor = args.get("actor") or args.get("actor_id")
    if not actor:
        raise ValueError("forget_actor requires 'actor'")
    delta = {"type": "ForgetActor", "actor": actor}
    return json.dumps(_post("/v1/cognitive/transact", {"delta": delta, "actor": "mcp"}))

def handle_merge_actor(args: dict) -> str:
    source = args.get("source", "").strip()
    target = args.get("target", "").strip()
    if not source or not target:
        raise ValueError("merge_actor requires 'source' and 'target'")
    return json.dumps(_post("/v1/actor/merge", {"source": source, "target": target}))

def handle_archive_record(args: dict) -> str:
    delta = {"type": "ArchiveRecord", "id": args["id"]}
    return json.dumps(_post("/v1/cognitive/transact", {"delta": delta, "actor": "mcp"}))


def handle_workspace_open(args: dict) -> str:
    delta = {"type": "WorkspaceOpen", "id": args["workspace_id"], "mode": args.get("mode", "Private")}
    return json.dumps(_post("/v1/cognitive/transact", {"delta": delta, "actor": "mcp"}))


def handle_workspace_merge(args: dict) -> str:
    delta = {"type": "WorkspaceMerge", "from": args["from_id"], "into": args["into_id"]}
    return json.dumps(_post("/v1/cognitive/transact", {"delta": delta, "actor": "mcp"}))


def handle_retract_belief(args: dict) -> str:
    delta = {"type": "RetractBelief", "id": args["belief_id"], "reason": args.get("reason", "retracted")}
    return json.dumps(_post("/v1/cognitive/transact", {"delta": delta, "actor": "mcp"}))


def handle_purge_expired(_args: dict) -> str:
    result = _post("/memory/consolidate", {"dry_run": False})
    deleted = result.get("deleted", 0)
    return f"✓ Purge completed. Deleted {deleted} expired records."


def handle_reflect(args: dict) -> str:
    query = args["query"]
    result = _post("/memory/reflect", {"query": query})
    if "error" in result and "hypothesis" not in result:
        return f"✗ Reflect failed: {result.get('error')}"
    hyp = result.get("hypothesis", "")
    conf = result.get("confidence", 0)
    evidence = result.get("evidence", [])
    loops = result.get("loops_run", 0)
    llm = result.get("llm_available", False)
    fallback = result.get("is_fallback", False)
    lines = [
        f"Reflect on: {query}",
        f"  Hypothesis:  {hyp}",
        f"  Confidence:  {conf}",
        f"  Loops run:   {loops}",
        f"  LLM:         {'available' if llm else 'unavailable'}",
        f"  Fallback:    {fallback}",
    ]
    if evidence:
        lines.append("  Evidence:")
        for e in evidence if isinstance(evidence, list) else [evidence]:
            lines.append(f"    • {e}")
    return "\n".join(lines)


def handle_predict(args: dict) -> str:
    state = args["state"]
    action = args["action"]
    result = _post("/worldmodel/predict", {"state": state, "action": action})
    if "error" in result and "probabilities" not in result:
        return f"✗ Predict failed: {result.get('error')}"
    probs = result.get("probabilities", {})
    entropy = result.get("entropy", 0)
    obs = result.get("observation_count", 0)
    from_state = result.get("from_state", state)
    lines = [
        f"Predict P(s'|{from_state}, {result.get('action', action)}):",
        f"  Entropy:            {entropy}",
        f"  Observation count:  {obs}",
    ]
    if probs:
        lines.append("  Next-state probabilities:")
        if isinstance(probs, dict):
            for s, p in sorted(probs.items(), key=lambda x: -float(x[1]) if x[1] is not None else 0):
                lines.append(f"    • {s}: {p}")
        else:
            lines.append(f"    {probs}")
    else:
        lines.append("  (no probability mass — observe transitions first)")
    return "\n".join(lines)


def handle_graph_ppr(args: dict) -> str:
    params: dict = {"limit": args.get("limit", 10)}
    if args.get("seed"):
        params["seed"] = args["seed"]
    qs = urllib.parse.urlencode(params)
    result = _get(f"/topo/ppr?{qs}")
    results = result.get("results", [])
    if not results:
        return f"No PPR results (seed={args.get('seed')}). Link nodes or apply a hypothesis first."
    lines = [f"• {r.get('id')} (score: {r.get('score', 0):.4f})" for r in results]
    return f"Topo PPR ({len(lines)}):\n" + "\n".join(lines)


def handle_deconstruct_hypothesis(args: dict) -> str:
    body: dict = {"text": args["text"]}
    if args.get("llm_json"):
        body["llm_json"] = args["llm_json"]
    apply = bool(args.get("apply", False))
    path = "/topo/apply-hyp" if apply else "/topo/deconstruct"
    result = _post(path, body)
    if not result.get("success", True) and result.get("error"):
        return f"✗ Deconstruct failed: {result.get('error')}"
    edges = result.get("edges") or result.get("hypothesis", {}).get("edges") or []
    nodes = result.get("nodes") or result.get("hypothesis", {}).get("nodes") or []
    lines = [f"Nodes: {', '.join(nodes) if nodes else '(none)'}"]
    if edges:
        lines.append("Edges:")
        for e in edges:
            if isinstance(e, dict):
                lines.append(
                    f"  • {e.get('from')} --[{e.get('relation', '?')}]--> {e.get('to')} "
                    f"(conf={e.get('confidence', '?')})"
                )
            else:
                lines.append(f"  • {e}")
    if apply:
        lines.append(
            f"Applied: nodes+={result.get('added_nodes', 0)} edges+={result.get('added_edges', 0)}"
        )
        if result.get("skipped"):
            lines.append(f"Skipped: {result.get('skipped')}")
    return "\n".join(lines)


def handle_check_topo_edge(args: dict) -> str:
    result = _post("/topo/check-edge", {"from": args["from"], "to": args["to"]})
    if result.get("error") and not result.get("success", True):
        return f"✗ check failed: {result.get('error')}"
    bad = result.get("would_contradict", False)
    report = result.get("report")
    if bad:
        reason = (report or {}).get("reason", "contradiction") if isinstance(report, dict) else "contradiction"
        return f"Would contradict: {args['from']} → {args['to']} ({reason})"
    return f"OK to add: {args['from']} → {args['to']} (no contradiction detected)"


def handle_rollout(args: dict) -> str:
    body: dict = {
        "initial_state": args["initial_state"],
        "mode": args.get("mode", "dirichlet"),
    }
    if "actions" in args:
        body["actions"] = args["actions"]
    if "goal_state" in args:
        body["goal_state"] = args["goal_state"]
    if "iterations" in args:
        body["iterations"] = args["iterations"]
    if "max_depth" in args:
        body["max_depth"] = args["max_depth"]
    result = _post("/worldmodel/rollout", body)
    if result.get("error") and "predicted_state" not in result:
        return f"✗ Rollout failed: {result.get('error')}"
    lines = [
        f"Rollout mode={result.get('mode', body.get('mode'))}",
        f"  initial: {result.get('initial_state', args['initial_state'])}",
        f"  predicted: {result.get('predicted_state', '?')}",
        f"  confidence: {result.get('confidence', '?')}",
    ]
    if result.get("best_action"):
        lines.append(f"  best_action: {result.get('best_action')}")
    if result.get("goal_state"):
        lines.append(f"  goal: {result.get('goal_state')}")
    return "\n".join(lines)


def handle_can_execute(args: dict) -> str:
    op = args["operation"]
    qs = urllib.parse.urlencode({"operation": op})
    result = _get(f"/self/can-execute?{qs}")
    if result.get("error") and "should_execute" not in result:
        return f"✗ can_execute failed: {result.get('error')}"
    ok = result.get("should_execute")
    conf = result.get("confidence", "?")
    rat = result.get("rationale", "")
    return f"can_execute({op}) = {ok} (confidence={conf})\n  {rat}".rstrip()


def handle_compute_state_diff(args: dict) -> str:
    from_tx = int(args.get("from_tx", 0))
    to_tx   = int(args.get("to_tx",   0))
    result = _post("/v1/state/diff", {"from_tx": from_tx, "to_tx": to_tx})
    if "error" in result:
        return f"✗ StateDiff error: {result['error']}"
    md = result.get("memory_delta", {})
    wm = result.get("world_model_delta", {})
    lines = [
        f"StateDiff tx[{from_tx}..{to_tx}]  count={result.get('tx_count', 0)}",
        f"  memory: +{len(md.get('added', []))} archived={len(md.get('archived', []))} "
        f"updated={len(md.get('updated', []))} net={md.get('net_delta', 0)}",
        f"  world_model: obs+{wm.get('observations_added', 0)} "
        f"dist_upd={wm.get('distributions_updated', 0)}",
        f"  causal_attributions: {len(result.get('causal_attributions', []))}",
    ]
    return "\n".join(lines)


def handle_consolidate_memory(args: dict) -> str:
    body: dict = {}
    if "min_group_size" in args:
        body["min_group_size"] = int(args["min_group_size"])
    result = _post("/v1/memory/consolidate", body)
    if "error" in result:
        return f"✗ Consolidate error: {result['error']}"
    return (
        f"Consolidated {result.get('groups_consolidated', 0)} groups — "
        f"archived {result.get('records_archived', 0)} records, "
        f"created {result.get('summary_records_created', 0)} summaries"
    )


def handle_twin_create(args: dict) -> str:
    body = {k: args[k] for k in ("dim", "dt", "max_covariance") if k in args}
    return json.dumps(_post("/v1/twin", body))


def handle_twin_step(args: dict) -> str:
    return json.dumps(_post(f"/v1/twin/{args['twin_id']}/step", {"action": args["action"]}))


def handle_twin_rollout(args: dict) -> str:
    return json.dumps(_post(f"/v1/twin/{args['twin_id']}/rollout", {"actions": args["actions"]}))


def handle_twin_get(args: dict) -> str:
    resp = requests.get(f"{HIPCORTEX_URL}/v1/twin/{args['twin_id']}", headers=_headers(), timeout=TIMEOUT)
    resp.raise_for_status()
    return json.dumps(resp.json())


def handle_experience_tiers(args: dict) -> str:
    actor = args["actor"]
    resp = requests.get(f"{HIPCORTEX_URL}/v1/experience/{actor}/tiers", headers=_headers(), timeout=TIMEOUT)
    resp.raise_for_status()
    data = resp.json()
    return (
        f"Experience tiers for {actor}: raw={data.get('raw', 0)}, "
        f"episode={data.get('episode', 0)}, abstract={data.get('abstract', 0)}, "
        f"compression_ratio={data.get('compression_ratio', 0.0):.2f}, "
        f"raw_pressure={data.get('raw_pressure', 0.0):.2f}"
    )


def handle_mgv_check(args: dict) -> str:
    r = _req("POST", "/v1/mgv/check", {
        "justification_strength": float(args.get("justification_strength", 0.8)),
        "calibration_score": float(args.get("calibration_score", 0.8)),
        "historical_success_rate": float(args.get("historical_success_rate", 0.8)),
    })
    return json.dumps(r)

def handle_causal_intervene(args: dict) -> str:
    var = args.get("var", "")
    value = float(args.get("value", 0.0))
    actor = args.get("actor", "mcp-session")
    r = _req("POST", "/v1/causal/intervene", {"var": var, "value": value, "actor": actor})
    return json.dumps(r)

def handle_causal_counterfactual(args: dict) -> str:
    r = _req("POST", "/v1/causal/counterfactual", {
        "actual_state": args.get("actual_state", {}),
        "intervention_var": args.get("intervention_var", ""),
        "intervention_value": float(args.get("intervention_value", 0.0)),
        "actor": args.get("actor", "mcp-session"),
    })
    return json.dumps(r)

def handle_causal_credit_assign(args: dict) -> str:
    r = _req("POST", "/v1/causal/credit-assign", {
        "failure_signal": args.get("failure_signal", "MaxIterations"),
        "actor": args.get("actor", "mcp-session"),
    })
    return json.dumps(r)

def handle_causal_rewrite_equation(args: dict) -> str:
    r = _req("POST", "/v1/causal/rewrite-equation", {
        "node_id": args.get("node_id", ""),
        "new_weights": args.get("new_weights", []),
        "actor": args.get("actor", "mcp-session"),
    })
    return json.dumps(r)

def handle_cognitive_report(args: dict) -> str:
    actor = args.get("actor", "mcp-session")
    r = _req("GET", f"/v1/cognitive/report?actor={actor}")
    return json.dumps(r)

def handle_list_authorized_actions(args: dict) -> str:
    r = _req("GET", "/v1/actions/authorized")
    return json.dumps(r)

def handle_get_provenance(args: dict) -> str:
    record_id = args.get("id", "")
    r = _req("GET", f"/v1/memory/{record_id}/provenance")
    return json.dumps(r)

def handle_run_omega_loop(args: dict) -> str:
    r = _req("POST", "/v1/loop/omega", {})
    return json.dumps(r)

def handle_recommend_tools(args: dict) -> str:
    task = args.get("task", "")
    r = _req("POST", "/agent/recommend-tools", {"task": task})
    return json.dumps(r)

def handle_clarify_goal(args: dict) -> str:
    r = _req("POST", "/agent/clarify-goal", {"task": args.get("task", "")})
    return json.dumps(r)

def handle_plan_validation(args: dict) -> str:
    r = _req("POST", "/agent/plan-validation", {"success_factors": args.get("success_factors", [])})
    return json.dumps(r)

def handle_check_progress(args: dict) -> str:
    r = _req("POST", "/agent/check-progress", {
        "success_factors": args.get("success_factors", []),
        "observations": args.get("observations", []),
        "iteration": args.get("iteration", 0),
        "max_iterations": args.get("max_iterations", 20),
    })
    return json.dumps(r)

def handle_should_exit(args: dict) -> str:
    r = _req("POST", "/agent/should-exit", {
        "iteration": args.get("iteration", 0),
        "max_iterations": args.get("max_iterations", 20),
        "progress_ratio": args.get("progress_ratio", 0.0),
        "surprise_signal": args.get("surprise_signal", 0.0),
    })
    return json.dumps(r)

def handle_loop_subscribe(args: dict) -> str:
    r = _req("POST", "/v1/loop/subscribe", {"actor": args.get("actor", "daemon")})
    return json.dumps(r)

def handle_loop_status(args: dict) -> str:
    handle_id = args.get("handle_id", "")
    r = _req("GET", f"/v1/loop/status/{handle_id}")
    return json.dumps(r)

def handle_get_verifier_report(args: dict) -> str:
    goal_id = args.get("goal_id", "")
    r = _req("GET", f"/goal/{goal_id}/verify")
    return json.dumps(r)

def dispatch_tool(name: str, args: dict) -> str:
    actor = args.get("actor", "_global")
    handlers = {
        "add_memory":       handle_add_memory,
        "search_memory":    handle_search_memory,
        "forget_actor":     handle_forget_actor,
        "merge_actor":      handle_merge_actor,
        "get_stats":        handle_get_stats,
        "search_code":      handle_search_code,
        "link_memories":    handle_link_memories,
        "get_neighbors":    handle_get_neighbors,
        "search_related":   handle_search_related,
        "graph_ppr":        handle_graph_ppr,
        "deconstruct_hypothesis": handle_deconstruct_hypothesis,
        "check_topo_edge":  handle_check_topo_edge,
        "rollout":          handle_rollout,
        "can_execute":      handle_can_execute,
        "delete_memory":    handle_delete_memory,
        "get_live_beliefs": handle_get_live_beliefs,
        "purge_expired":    handle_purge_expired,
        "reflect":          handle_reflect,
        "predict":              handle_predict,
        "compute_state_diff":   handle_compute_state_diff,
        "simulate_rollout":     handle_simulate_rollout,
        "get_system_health":    handle_get_system_health,
        "cognitive_transact":   handle_cognitive_transact,
        "open_intent":          handle_open_intent,
        "accept_receipt":       handle_accept_receipt,
        "cognitive_diff":       handle_cognitive_diff,
        "self_health":          handle_self_health,
        "cognitive_snapshot":   handle_cognitive_snapshot,
        "fork_create":          handle_fork_create,
        "fork_step":            handle_fork_step,
        "fork_snapshot":        handle_fork_snapshot,
        "fork_delete":          handle_fork_delete,
        "fork_rollout":         handle_fork_rollout,
        "consolidate_memory":   handle_p5_consolidate,
        "get_state_export":     handle_get_state_export,
        "forget_actor":         handle_forget_actor,
        "archive_record":       handle_archive_record,
        "workspace_open":       handle_workspace_open,
        "workspace_merge":      handle_workspace_merge,
        "retract_belief":       handle_retract_belief,
        "twin_create":          handle_twin_create,
        "twin_step":            handle_twin_step,
        "twin_rollout":         handle_twin_rollout,
        "twin_get":             handle_twin_get,
        "experience_tiers":     handle_experience_tiers,
        "mgv_check":            handle_mgv_check,
        "causal_intervene":     handle_causal_intervene,
        "causal_counterfactual": handle_causal_counterfactual,
        "causal_credit_assign": handle_causal_credit_assign,
        "causal_rewrite_equation": handle_causal_rewrite_equation,
        "cognitive_report":        handle_cognitive_report,
        "list_authorized_actions": handle_list_authorized_actions,
        "get_provenance":          handle_get_provenance,
        "run_omega_loop":          handle_run_omega_loop,
        "recommend_tools":         handle_recommend_tools,
        "clarify_goal":            handle_clarify_goal,
        "plan_validation":         handle_plan_validation,
        "check_progress":          handle_check_progress,
        "should_exit":             handle_should_exit,
        "loop_subscribe":          handle_loop_subscribe,
        "loop_status":             handle_loop_status,
        "get_verifier_report":     handle_get_verifier_report,
        "get_budget":              handle_get_budget,
    }
    handler = handlers.get(name)
    if handler is None:
        raise ValueError(f"Unknown tool: {name}")
    result = handler(args)
    if name in ("get_live_beliefs", "reflect"):
        _live_beliefs_seen_actors.add(actor)
    elif name == "search_memory":
        soft_on = os.getenv("HIPCORTEX_HARNESS_SOFT", "1") != "0"
        if soft_on and actor not in _live_beliefs_seen_actors:
            result = _HARNESS_SEARCH_WARN + "\n" + result
    return result

# ---------------------------------------------------------------------------
# JSON-RPC 2.0 transport
# ---------------------------------------------------------------------------

def respond(id_: Any, result: Any = None, error: Any = None) -> None:
    msg: dict = {"jsonrpc": "2.0", "id": id_}
    if error is not None:
        msg["error"] = {"code": -32000, "message": str(error)}
    else:
        msg["result"] = result
    sys.stdout.write(json.dumps(msg) + "\n")
    sys.stdout.flush()


def handle_resources_list() -> dict:
    return {"resources": RESOURCES}


def handle_resource_read(uri: str) -> dict:
    try:
        if uri == "hipcortex://context/relevant":
            data = _get("/memory/search?q=context&limit=5")
            lines = []
            for item in (data if isinstance(data, list) else []):
                actor = item.get("actor", "")
                action = item.get("action", "")
                target = item.get("target", "")
                lines.append(f"[{actor}] {action} → {target}")
            text = "\n".join(lines) if lines else "(no memories yet)"
            return {"contents": [{"uri": uri, "mimeType": "text/plain", "text": text}]}
        elif uri in ("hipcortex://beliefs/current", "hipcortex://beliefs/live"):
            data = _get("/v1/beliefs")
            return {
                "contents": [
                    {
                        "uri": uri,
                        "mimeType": "application/json",
                        "text": json.dumps(data if isinstance(data, list) else data),
                    }
                ]
            }
        elif uri == "hipcortex://state/diff":
            # Get current tx, compute diff over last 5 transactions
            try:
                snap = _get("/v1/cognitive/snapshot")
                head = snap.get("tx_cursor", 0)
                from_tx = max(0, head - 5)
                data = _get(f"/v1/state/diff?from_tx={from_tx}&to_tx={head}")
            except Exception:
                data = {}
            return {
                "contents": [
                    {
                        "uri": uri,
                        "mimeType": "application/json",
                        "text": json.dumps(data),
                    }
                ]
            }
        elif uri == "hipcortex://self/health":
            data = _get("/v1/self/health")
            return {
                "contents": [
                    {
                        "uri": uri,
                        "mimeType": "application/json",
                        "text": json.dumps(data),
                    }
                ]
            }
        elif uri == "hipcortex://context/conversation":
            actor = os.environ.get("HIPCORTEX_ACTOR", "mcp-session")
            data = _get(f"/memory/query?actor={actor}&limit=20")
            lines = []
            for item in (data if isinstance(data, list) else []):
                lines.append(f"{item.get('action', '')} → {item.get('target', '')}")
            text = "\n".join(lines) if lines else "(no history yet)"
            return {"contents": [{"uri": uri, "mimeType": "text/plain", "text": text}]}
        elif uri == "hipcortex://experience/tiers":
            actor = os.environ.get("HIPCORTEX_ACTOR", "mcp-session")
            try:
                resp = requests.get(f"{HIPCORTEX_URL}/v1/experience/{actor}/tiers", headers=_headers(), timeout=TIMEOUT)
                data = resp.json() if resp.ok else {}
            except Exception:
                data = {}
            return {"contents": [{"uri": uri, "mimeType": "application/json", "text": json.dumps(data)}]}
        else:
            return {"contents": [{"uri": uri, "mimeType": "text/plain", "text": ""}]}
    except Exception:
        return {"contents": [{"uri": uri, "mimeType": "text/plain", "text": ""}]}


def main() -> None:
    for raw_line in sys.stdin:
        line = raw_line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError as e:
            respond(None, error=f"JSON parse error: {e}")
            continue

        method = req.get("method", "")
        id_    = req.get("id")
        params = req.get("params", {})

        if method == "initialize":
            respond(id_, {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}, "resources": {}},
                "serverInfo": {"name": "hipcortex", "version": "3.13.0"},
            })
        elif method == "initialized":
            pass  # notification — no response
        elif method == "tools/list":
            respond(id_, {"tools": TOOLS})
        elif method == "tools/call":
            tool_name = params.get("name", "")
            tool_args = params.get("arguments", {})
            try:
                content = dispatch_tool(tool_name, tool_args)
                respond(id_, {"content": [{"type": "text", "text": content}]})
            except requests.RequestException as e:
                respond(id_, error=f"HipCortex server error: {e}")
            except Exception as e:
                respond(id_, error=str(e))
        elif method == "resources/list":
            respond(id_, handle_resources_list())
        elif method == "resources/read":
            respond(id_, handle_resource_read(params.get("uri", "")))
        elif method == "ping":
            respond(id_, {})
        else:
            if id_ is not None:
                respond(id_, error=f"Unknown method: {method}")


if __name__ == "__main__":
    main()
